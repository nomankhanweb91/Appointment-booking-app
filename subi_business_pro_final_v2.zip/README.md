# Subi Business Pro — Appointment, Store Billing, Multi-Service & Clean Invoices

Production-ready commercial application built in Flutter with local SQLite persistent storage.

### Key Highlights:
1. **Custom Gold Beauty Icon Included:** Custom logo integrated into Android launcher resources.
2. **Services Are Optional:** Appointment booking does not require choosing a service; amount can be entered manually.
3. **Direct Service Checklist:** In Book Appointment, services appear with clean checkboxes for instant multi-selection.
4. **No Ledger & No Transaction History in PDF:** Both Appointment and Store Bill PDFs strictly output clean retail invoices without any ledger tables or balances.
5. **Multiple Offer Banners in PDF:** Banner images uploaded for offers print attractively in the bill footer.
6. **Luxury Modern UI:** Navy & Gold palette with refined cards, soft shadows, and clean modern spacing.
