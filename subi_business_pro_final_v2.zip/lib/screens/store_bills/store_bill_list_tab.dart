import 'package:flutter/material.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../services/pdf/pdf_invoice_service.dart';
import '../../theme/app_theme.dart';
import 'create_store_bill_screen.dart';

class StoreBillListTab extends StatefulWidget {
  const StoreBillListTab({super.key});

  @override
  State<StoreBillListTab> createState() => _StoreBillListTabState();
}

class _StoreBillListTabState extends State<StoreBillListTab> {
  final _searchCtrl = TextEditingController();
  List<StoreBill> _bills = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchBills();
  }

  Future<void> _fetchBills() async {
    final list = await DatabaseHelper.instance.getStoreBills(query: _searchCtrl.text.trim());
    setState(() {
      _bills = list;
      _loading = false;
    });
  }

  void _confirmDelete(StoreBill bill) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Store Bill?'),
        content: Text('Are you sure you want to delete ${bill.billNumber}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.statusRed),
            onPressed: () async {
              await DatabaseHelper.instance.deleteStoreBill(bill.id!);
              Navigator.pop(ctx);
              _fetchBills();
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add, color: Colors.white),
                label: const Text('+ Create New Bill', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                onPressed: () async {
                  final res = await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateStoreBillScreen()));
                  if (res == true) _fetchBills();
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search Bill#, Customer, Mobile...',
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.all(10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onChanged: (_) => _fetchBills(),
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _bills.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('No Store Bills Yet', style: TextStyle(fontSize: 16, color: Colors.grey)),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () async {
                                final res = await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateStoreBillScreen()));
                                if (res == true) _fetchBills();
                              },
                              child: const Text('+ Create New Bill'),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _bills.length,
                        itemBuilder: (context, idx) {
                          final b = _bills[idx];
                          return Card(
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            child: ListTile(
                              title: Text('${b.customerName} (${b.billNumber})', style: const TextStyle(fontWeight: FontWeight.w800)),
                              subtitle: Text('Mobile: ${b.mobile} | Date: ${b.createdAt}'),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('₹${b.totalAmount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                                  IconButton(
                                    icon: const Icon(Icons.edit, size: 20),
                                    onPressed: () async {
                                      final res = await Navigator.push(
                                        context,
                                        MaterialPageRoute(builder: (_) => CreateStoreBillScreen(editBill: b)),
                                      );
                                      if (res == true) _fetchBills();
                                    },
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.print, color: AppTheme.primaryNavy),
                                    onPressed: () => PdfInvoiceService.printStoreBill(bill: b),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                    onPressed: () => _confirmDelete(b),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
