import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../services/pdf/pdf_invoice_service.dart';
import '../../theme/app_theme.dart';

class CreateStoreBillScreen extends StatefulWidget {
  final StoreBill? editBill;
  const CreateStoreBillScreen({super.key, this.editBill});

  @override
  State<CreateStoreBillScreen> createState() => _CreateStoreBillScreenState();
}

class _CreateStoreBillScreenState extends State<CreateStoreBillScreen> {
  final _customerNameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _itemNameCtrl = TextEditingController();
  final _itemPriceCtrl = TextEditingController();

  List<StoreBillItem> _items = [];

  double get _totalAmount => _items.fold(0.0, (sum, i) => sum + i.itemPrice);

  @override
  void initState() {
    super.initState();
    if (widget.editBill != null) {
      final b = widget.editBill!;
      _customerNameCtrl.text = b.customerName;
      _mobileCtrl.text = b.mobile;
      _items = List.from(b.items);
    }
  }

  void _addItem() {
    final name = _itemNameCtrl.text.trim();
    final price = double.tryParse(_itemPriceCtrl.text.trim());
    if (name.isNotEmpty && price != null && price > 0) {
      setState(() {
        _items.add(StoreBillItem(itemName: name, itemPrice: price));
        _itemNameCtrl.clear();
        _itemPriceCtrl.clear();
      });
    }
  }

  Future<void> _submitBill() async {
    if (_customerNameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Customer Name is required')));
      return;
    }
    if (_mobileCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mobile Number is required')));
      return;
    }
    if (_items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please add at least one item')));
      return;
    }

    final now = DateTime.now();
    final dateStr = DateFormat('yyyy-MM-dd').format(now);
    final timeStr = DateFormat('hh:mm a').format(now);

    if (widget.editBill != null) {
      final b = widget.editBill!;
      final updated = StoreBill(
        id: b.id,
        billNumber: b.billNumber,
        customerName: _customerNameCtrl.text.trim(),
        mobile: _mobileCtrl.text.trim(),
        items: _items,
        totalAmount: _totalAmount,
        paidAmount: _totalAmount,
        dueAmount: 0.0,
        paymentStatus: 'Paid',
        createdAt: b.createdAt,
        updatedAt: '$dateStr $timeStr',
      );
      await DatabaseHelper.instance.updateStoreBill(updated);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Store Bill Updated')));
        Navigator.pop(context, true);
      }
    } else {
      final autoBillNumber = await DatabaseHelper.instance.getNextStoreBillNumber();
      final bill = StoreBill(
        billNumber: autoBillNumber,
        customerName: _customerNameCtrl.text.trim(),
        mobile: _mobileCtrl.text.trim(),
        items: _items,
        totalAmount: _totalAmount,
        paidAmount: _totalAmount,
        dueAmount: 0.0,
        paymentStatus: 'Paid',
        createdAt: '$dateStr $timeStr',
        updatedAt: '$dateStr $timeStr',
      );
      await DatabaseHelper.instance.createStoreBill(bill);
      if (mounted) {
        Navigator.pop(context, true);
        await PdfInvoiceService.printStoreBill(bill: bill);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.editBill != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEdit ? 'Edit Store Bill' : 'Create Store Bill')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            TextField(controller: _customerNameCtrl, decoration: const InputDecoration(labelText: 'Customer Name *')),
            const SizedBox(height: 12),
            TextField(
              controller: _mobileCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Mobile Number *'),
            ),
            const Divider(height: 32),

            const Text('Add Products / Items', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.primaryNavy)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextField(controller: _itemNameCtrl, decoration: const InputDecoration(labelText: 'Item Name')),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _itemPriceCtrl,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Price (₹)'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.add_circle, color: AppTheme.primaryNavy, size: 38),
                  onPressed: _addItem,
                ),
              ],
            ),
            const SizedBox(height: 14),

            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _items.length,
              itemBuilder: (context, idx) {
                final item = _items[idx];
                return ListTile(
                  dense: true,
                  title: Text(item.itemName, style: const TextStyle(fontWeight: FontWeight.w700)),
                  trailing: Text('₹${item.itemPrice.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900)),
                  leading: IconButton(
                    icon: const Icon(Icons.remove_circle, color: Colors.red, size: 22),
                    onPressed: () => setState(() => _items.removeAt(idx)),
                  ),
                );
              },
            ),
            const Divider(height: 32),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total Amount:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                Text(
                  '₹${_totalAmount.toStringAsFixed(0)}',
                  style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppTheme.primaryNavy),
                ),
              ],
            ),
            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _submitBill,
                child: Text(isEdit ? 'Update Bill' : 'Save & Print Bill', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
