import 'package:flutter/material.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../theme/app_theme.dart';
import '../appointments/appointment_view_screen.dart';

class HomeScreen extends StatefulWidget {
  final Function(int) onNavigateTab;
  const HomeScreen({super.key, required this.onNavigateTab});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, dynamic> _metrics = {
    'totalAppointments': 0,
    'totalStoreBills': 0,
    'totalDueAmount': 0.0,
    'totalPaidAmount': 0.0,
  };

  List<Appointment> _recentAppointments = [];
  List<StoreBill> _recentStoreBills = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    final metrics = await DatabaseHelper.instance.getDashboardMetrics();
    final apts = await DatabaseHelper.instance.getAppointments();
    final bills = await DatabaseHelper.instance.getStoreBills();

    setState(() {
      _metrics = metrics;
      _recentAppointments = apts.take(5).toList();
      _recentStoreBills = bills.take(5).toList();
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator(color: AppTheme.accentGold));
    }

    return RefreshIndicator(
      onRefresh: loadDashboard,
      color: AppTheme.accentGold,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Analytics Metric Grid
            Row(
              children: [
                Expanded(
                  child: _buildLuxuryCard(
                    title: 'Total Appointment',
                    value: '${_metrics['totalAppointments']}',
                    icon: Icons.auto_awesome,
                    accentColor: const Color(0xFFD4AF37),
                    onTap: () => widget.onNavigateTab(1),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildLuxuryCard(
                    title: 'Total Store Bill',
                    value: '${_metrics['totalStoreBills']}',
                    icon: Icons.receipt_long,
                    accentColor: const Color(0xFF3B82F6),
                    onTap: () => widget.onNavigateTab(2),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: _buildLuxuryCard(
                    title: 'Appointment Due',
                    value: '₹${(_metrics['totalDueAmount'] as double).toStringAsFixed(0)}',
                    icon: Icons.pending_actions,
                    accentColor: AppTheme.statusRed,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildLuxuryCard(
                    title: 'Appointment Paid',
                    value: '₹${(_metrics['totalPaidAmount'] as double).toStringAsFixed(0)}',
                    icon: Icons.check_circle_outline,
                    accentColor: AppTheme.statusGreen,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 28),

            // Recent Appointments
            _buildSectionTitle(
              title: 'Upcoming Bookings',
              onViewAll: () => widget.onNavigateTab(1),
            ),
            const SizedBox(height: 10),
            _recentAppointments.isEmpty
                ? _buildEmptyPlaceholder('No appointments booked yet')
                : Column(
                    children: _recentAppointments.map((apt) => _buildAppointmentCard(apt)).toList(),
                  ),

            const SizedBox(height: 28),

            // Recent Store Bills
            _buildSectionTitle(
              title: 'Recent Store Bills',
              onViewAll: () => widget.onNavigateTab(2),
            ),
            const SizedBox(height: 10),
            _recentStoreBills.isEmpty
                ? _buildEmptyPlaceholder('No store bills generated yet')
                : Column(
                    children: _recentStoreBills.map((bill) => _buildStoreBillCard(bill)).toList(),
                  ),
          ],
        ),
      ),
    );
  }

  Widget _buildLuxuryCard({
    required String title,
    required String value,
    required IconData icon,
    required Color accentColor,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: Colors.grey.shade100),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.03),
              blurRadius: 12,
              offset: const Offset(0, 4),
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: accentColor, size: 22),
                ),
                if (onTap != null)
                  Icon(Icons.arrow_forward_ios, size: 12, color: Colors.grey.shade400),
              ],
            ),
            const SizedBox(height: 16),
            Text(
              value,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppTheme.primaryNavy),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle({required String title, required VoidCallback onViewAll}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppTheme.primaryNavy),
        ),
        TextButton(
          onPressed: onViewAll,
          child: const Text('View All', style: TextStyle(fontWeight: FontWeight.w700, color: AppTheme.royalIndigo)),
        )
      ],
    );
  }

  Widget _buildAppointmentCard(Appointment apt) {
    final servicesText = apt.services.isEmpty
        ? 'No specific service'
        : apt.services.map((s) => s.serviceName).join(', ');

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        title: Text('${apt.customerName} (${apt.appointmentNumber})', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text('Mobile: ${apt.mobile}'),
            Text('Services: $servicesText', maxLines: 1, overflow: TextOverflow.ellipsis),
            Text('Marriage Date: ${apt.dateOfMarriage}', style: const TextStyle(color: Colors.pink, fontWeight: FontWeight.bold)),
          ],
        ),
        trailing: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Text('₹${apt.totalAmount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            Text(
              apt.dueAmount > 0 ? 'Due: ₹${apt.dueAmount.toStringAsFixed(0)}' : 'Paid',
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: apt.dueAmount > 0 ? AppTheme.statusRed : AppTheme.statusGreen,
              ),
            ),
          ],
        ),
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => AppointmentViewScreen(appointmentId: apt.id!)));
          loadDashboard();
        },
      ),
    );
  }

  Widget _buildStoreBillCard(StoreBill bill) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        title: Text('${bill.customerName} (${bill.billNumber})', style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('Mobile: ${bill.mobile} | Date: ${bill.createdAt}'),
        trailing: Text(
          '₹${bill.totalAmount.toStringAsFixed(0)}',
          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: AppTheme.primaryNavy),
        ),
      ),
    );
  }

  Widget _buildEmptyPlaceholder(String message) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100),
      ),
      child: Center(
        child: Text(message, style: TextStyle(color: Colors.grey.shade400, fontWeight: FontWeight.w600)),
      ),
    );
  }
}
