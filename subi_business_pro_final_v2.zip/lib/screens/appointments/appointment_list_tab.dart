import 'package:flutter/material.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../services/pdf/pdf_invoice_service.dart';
import '../../theme/app_theme.dart';
import 'book_appointment_screen.dart';
import 'appointment_view_screen.dart';

class AppointmentListTab extends StatefulWidget {
  const AppointmentListTab({super.key});

  @override
  State<AppointmentListTab> createState() => _AppointmentListTabState();
}

class _AppointmentListTabState extends State<AppointmentListTab> {
  final _searchCtrl = TextEditingController();
  String _statusFilter = 'All';
  List<Appointment> _appointments = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    final list = await DatabaseHelper.instance.getAppointments(
      query: _searchCtrl.text.trim(),
      statusFilter: _statusFilter,
    );
    setState(() {
      _appointments = list;
      _loading = false;
    });
  }

  Map<String, dynamic> _getDatePriority(String marriageDateStr) {
    try {
      final eventDate = DateTime.parse(marriageDateStr);
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);
      final target = DateTime(eventDate.year, eventDate.month, eventDate.day);
      final diff = target.difference(today).inDays;

      if (diff == 0) {
        return {
          'color': AppTheme.dateToday,
          'border': Colors.pink.shade300,
          'label': 'TODAY 🌸',
          'labelColor': Colors.pink.shade900,
        };
      } else if (diff == 1) {
        return {
          'color': AppTheme.dateTomorrow,
          'border': Colors.red.shade400,
          'label': 'TOMORROW 🔴',
          'labelColor': Colors.red.shade900,
        };
      } else if (diff == 2) {
        return {
          'color': AppTheme.dateDayAfter,
          'border': Colors.amber.shade400,
          'label': 'DAY AFTER TOMORROW 🟡',
          'labelColor': Colors.amber.shade900,
        };
      } else if (diff > 2) {
        return {
          'color': AppTheme.dateUpcoming,
          'border': Colors.green.shade400,
          'label': 'UPCOMING 🟢',
          'labelColor': Colors.green.shade900,
        };
      } else {
        return {
          'color': AppTheme.datePast,
          'border': Colors.grey.shade300,
          'label': 'PAST',
          'labelColor': Colors.grey.shade600,
        };
      }
    } catch (_) {
      return {
        'color': AppTheme.datePast,
        'border': Colors.grey.shade300,
        'label': 'NORMAL',
        'labelColor': Colors.grey.shade600,
      };
    }
  }

  void _confirmDelete(Appointment apt) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Appointment?'),
        content: Text('Are you sure you want to delete ${apt.appointmentNumber} for ${apt.customerName}?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.statusRed),
            onPressed: () async {
              await DatabaseHelper.instance.deleteAppointment(apt.id!);
              Navigator.pop(ctx);
              _fetchAppointments();
            },
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add, color: Colors.white),
                label: const Text('+ Book Appointment', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                onPressed: () async {
                  final res = await Navigator.push(context, MaterialPageRoute(builder: (_) => const BookAppointmentScreen()));
                  if (res == true) _fetchAppointments();
                },
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchCtrl,
                    decoration: InputDecoration(
                      hintText: 'Search Customer, Mobile, No...',
                      prefixIcon: const Icon(Icons.search),
                      contentPadding: const EdgeInsets.all(10),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onChanged: (_) => _fetchAppointments(),
                  ),
                ),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: _statusFilter,
                  items: const [
                    DropdownMenuItem(value: 'All', child: Text('All')),
                    DropdownMenuItem(value: 'Paid', child: Text('Paid')),
                    DropdownMenuItem(value: 'Due', child: Text('Due')),
                  ],
                  onChanged: (v) {
                    setState(() => _statusFilter = v!);
                    _fetchAppointments();
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _appointments.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text('No Appointments Yet', style: TextStyle(fontSize: 16, color: Colors.grey)),
                            const SizedBox(height: 12),
                            ElevatedButton(
                              onPressed: () async {
                                final res = await Navigator.push(context, MaterialPageRoute(builder: (_) => const BookAppointmentScreen()));
                                if (res == true) _fetchAppointments();
                              },
                              child: const Text('+ Book Appointment'),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        itemCount: _appointments.length,
                        itemBuilder: (context, idx) {
                          final apt = _appointments[idx];
                          final priority = _getDatePriority(apt.dateOfMarriage);
                          final servicesText = apt.services.isEmpty
                              ? 'No services assigned'
                              : apt.services.map((s) => s.serviceName).join(', ');

                          return Card(
                            color: priority['color'],
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                              side: BorderSide(color: priority['border'], width: 1.2),
                            ),
                            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            child: Padding(
                              padding: const EdgeInsets.all(14),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          '${apt.customerName} (${apt.appointmentNumber})',
                                          style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.circular(8),
                                          border: Border.all(color: priority['border']),
                                        ),
                                        child: Text(
                                          priority['label'],
                                          style: TextStyle(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w900,
                                            color: priority['labelColor'],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 6),
                                  Text('Phone: ${apt.mobile}'),
                                  Text('Marriage Date: ${apt.dateOfMarriage}', style: const TextStyle(fontWeight: FontWeight.w800, color: Colors.pink)),
                                  Text('Services: $servicesText', maxLines: 1, overflow: TextOverflow.ellipsis),
                                  const SizedBox(height: 8),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text('Total: ₹${apt.totalAmount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                                      Text('Paid: ₹${apt.paidAmount.toStringAsFixed(0)}', style: const TextStyle(color: AppTheme.statusGreen, fontWeight: FontWeight.bold)),
                                      Text(
                                        'Due: ₹${apt.dueAmount.toStringAsFixed(0)}',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: apt.dueAmount > 0 ? AppTheme.statusRed : AppTheme.statusGreen,
                                        ),
                                      ),
                                    ],
                                  ),
                                  const Divider(),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      TextButton(
                                        child: const Text('View'),
                                        onPressed: () async {
                                          await Navigator.push(context, MaterialPageRoute(builder: (_) => AppointmentViewScreen(appointmentId: apt.id!)));
                                          _fetchAppointments();
                                        },
                                      ),
                                      TextButton(
                                        child: const Text('Edit'),
                                        onPressed: () async {
                                          final res = await Navigator.push(
                                            context,
                                            MaterialPageRoute(builder: (_) => BookAppointmentScreen(editAppointment: apt)),
                                          );
                                          if (res == true) _fetchAppointments();
                                        },
                                      ),
                                      TextButton(
                                        child: const Text('Print Bill'),
                                        onPressed: () => PdfInvoiceService.printAppointmentBill(appointment: apt),
                                      ),
                                      IconButton(
                                        icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                        onPressed: () => _confirmDelete(apt),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
