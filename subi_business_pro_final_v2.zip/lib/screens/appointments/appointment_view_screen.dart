import 'package:flutter/material.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../services/launcher/url_launcher_service.dart';
import '../../services/pdf/pdf_invoice_service.dart';
import '../../theme/app_theme.dart';
import 'book_appointment_screen.dart';

class AppointmentViewScreen extends StatefulWidget {
  final int appointmentId;
  const AppointmentViewScreen({super.key, required this.appointmentId});

  @override
  State<AppointmentViewScreen> createState() => _AppointmentViewScreenState();
}

class _AppointmentViewScreenState extends State<AppointmentViewScreen> {
  Appointment? _appointment;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final apt = await DatabaseHelper.instance.getAppointmentById(widget.appointmentId);
    setState(() {
      _appointment = apt;
      _loading = false;
    });
  }

  void _showJobDoneModal() {
    final apt = _appointment!;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 20, right: 20, top: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Job Done Confirmation', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Divider(height: 24),
              _row('Customer Name:', apt.customerName),
              _row('Total Amount:', '₹${apt.totalAmount.toStringAsFixed(0)}'),
              _row('Already Paid:', '₹${apt.paidAmount.toStringAsFixed(0)}'),
              _row('Due Amount:', '₹${apt.dueAmount.toStringAsFixed(0)}', color: AppTheme.statusRed),
              const SizedBox(height: 16),
              if (apt.dueAmount > 0) ...[
                const Text('Kya Due Amount receive ho gaya hai?', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: AppTheme.statusGreen),
                        onPressed: () async {
                          Navigator.pop(context);
                          final updated = Appointment(
                            id: apt.id,
                            appointmentNumber: apt.appointmentNumber,
                            customerName: apt.customerName,
                            mobile: apt.mobile,
                            dateOfMarriage: apt.dateOfMarriage,
                            address: apt.address,
                            services: apt.services,
                            totalAmount: apt.totalAmount,
                            paidAmount: apt.totalAmount,
                            dueAmount: 0.0,
                            jobStatus: 'Job Done',
                            paymentStatus: 'Paid',
                            createdAt: apt.createdAt,
                            updatedAt: DateTime.now().toString(),
                          );
                          await DatabaseHelper.instance.updateAppointment(updated);
                          _loadData();
                        },
                        child: const Text('Yes, Received'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () async {
                          Navigator.pop(context);
                          final updated = Appointment(
                            id: apt.id,
                            appointmentNumber: apt.appointmentNumber,
                            customerName: apt.customerName,
                            mobile: apt.mobile,
                            dateOfMarriage: apt.dateOfMarriage,
                            address: apt.address,
                            services: apt.services,
                            totalAmount: apt.totalAmount,
                            paidAmount: apt.paidAmount,
                            dueAmount: apt.dueAmount,
                            jobStatus: 'Job Done',
                            paymentStatus: 'Due',
                            createdAt: apt.createdAt,
                            updatedAt: DateTime.now().toString(),
                          );
                          await DatabaseHelper.instance.updateAppointment(updated);
                          _loadData();
                        },
                        child: const Text('No, Keep Due'),
                      ),
                    ),
                  ],
                )
              ] else ...[
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      Navigator.pop(context);
                      final updated = Appointment(
                        id: apt.id,
                        appointmentNumber: apt.appointmentNumber,
                        customerName: apt.customerName,
                        mobile: apt.mobile,
                        dateOfMarriage: apt.dateOfMarriage,
                        address: apt.address,
                        services: apt.services,
                        totalAmount: apt.totalAmount,
                        paidAmount: apt.paidAmount,
                        dueAmount: 0.0,
                        jobStatus: 'Job Done',
                        paymentStatus: 'Paid',
                        createdAt: apt.createdAt,
                        updatedAt: DateTime.now().toString(),
                      );
                      await DatabaseHelper.instance.updateAppointment(updated);
                      _loadData();
                    },
                    child: const Text('Confirm Job Done'),
                  ),
                ),
              ],
              const SizedBox(height: 24),
            ],
          ),
        );
      },
    );
  }

  Widget _row(String label, String val, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.w500)),
          Text(val, style: TextStyle(fontWeight: FontWeight.bold, color: color ?? AppTheme.primaryNavy)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading || _appointment == null) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    final apt = _appointment!;

    return Scaffold(
      appBar: AppBar(
        title: Text('${apt.appointmentNumber} Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Edit Appointment',
            onPressed: () async {
              final res = await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => BookAppointmentScreen(editAppointment: apt)),
              );
              if (res == true) _loadData();
            },
          ),
          IconButton(
            icon: const Icon(Icons.print),
            tooltip: 'Print Bill',
            onPressed: () => PdfInvoiceService.printAppointmentBill(appointment: apt),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(apt.customerName, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
                        Row(
                          children: [
                            IconButton(
                              icon: const Icon(Icons.call, color: AppTheme.primaryNavy),
                              onPressed: () => UrlLauncherService.makePhoneCall(apt.mobile),
                            ),
                            IconButton(
                              icon: const Icon(Icons.chat, color: AppTheme.statusGreen),
                              onPressed: () => UrlLauncherService.openWhatsApp(apt.mobile, message: 'Hello ${apt.customerName}, regarding your booking ${apt.appointmentNumber}.'),
                            ),
                          ],
                        )
                      ],
                    ),
                    Text('Mobile: ${apt.mobile}'),
                    Text('Address: ${apt.address}'),
                    const SizedBox(height: 6),
                    Text('Marriage Date: ${apt.dateOfMarriage}', style: const TextStyle(color: Colors.pink, fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),

            if (apt.services.isNotEmpty) ...[
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Booked Services', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                      const Divider(),
                      ...apt.services.map(
                        (s) => Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(s.serviceName),
                              Text('₹${s.amount.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],

            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _row('Total Amount:', '₹${apt.totalAmount.toStringAsFixed(0)}'),
                    _row('Paid Amount:', '₹${apt.paidAmount.toStringAsFixed(0)}', color: AppTheme.statusGreen),
                    const Divider(),
                    _row('Due Amount:', '₹${apt.dueAmount.toStringAsFixed(0)}', color: apt.dueAmount > 0 ? AppTheme.statusRed : AppTheme.statusGreen),
                    _row('Job Status:', apt.jobStatus, color: apt.jobStatus == 'Job Done' ? AppTheme.statusGreen : AppTheme.statusAmber),
                    _row('Payment Status:', apt.paymentStatus, color: apt.paymentStatus == 'Paid' ? AppTheme.statusGreen : AppTheme.statusRed),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            if (apt.jobStatus != 'Job Done')
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.check_circle_outline),
                  label: const Text('✓ Job Done'),
                  onPressed: _showJobDoneModal,
                ),
              ),

            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.receipt_long),
                label: const Text('Print Final Invoice (PDF)'),
                onPressed: () => PdfInvoiceService.printAppointmentBill(appointment: apt),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
