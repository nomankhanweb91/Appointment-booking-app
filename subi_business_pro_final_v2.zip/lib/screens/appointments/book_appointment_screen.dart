import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../theme/app_theme.dart';

class BookAppointmentScreen extends StatefulWidget {
  final Appointment? editAppointment;
  const BookAppointmentScreen({super.key, this.editAppointment});

  @override
  State<BookAppointmentScreen> createState() => _BookAppointmentScreenState();
}

class _BookAppointmentScreenState extends State<BookAppointmentScreen> {
  final _nameCtrl = TextEditingController();
  final _mobileCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  final _totalAmountCtrl = TextEditingController(text: '0');
  final _paidAmountCtrl = TextEditingController(text: '0');
  final _upiTxnCtrl = TextEditingController();

  DateTime? _dateOfMarriage;
  List<ServiceModel> _allAvailableServices = [];
  
  // Track selected services and individual prices
  final Set<int> _selectedServiceIds = {};
  final Map<int, TextEditingController> _servicePriceControllers = {};

  String _paymentMethod = 'Cash';

  double get _totalAmount => double.tryParse(_totalAmountCtrl.text.trim()) ?? 0.0;
  double get _paidAmount => double.tryParse(_paidAmountCtrl.text.trim()) ?? 0.0;
  double get _dueAmount => (_totalAmount - _paidAmount).clamp(0.0, double.infinity);

  @override
  void initState() {
    super.initState();
    _loadServices();
  }

  Future<void> _loadServices() async {
    final list = await DatabaseHelper.instance.getServices(activeOnly: true);
    setState(() {
      _allAvailableServices = list;
    });

    for (var s in list) {
      _servicePriceControllers[s.id!] = TextEditingController(
        text: s.servicePrice != null ? s.servicePrice!.toStringAsFixed(0) : '',
      );
    }

    if (widget.editAppointment != null) {
      final apt = widget.editAppointment!;
      _nameCtrl.text = apt.customerName;
      _mobileCtrl.text = apt.mobile;
      _addressCtrl.text = apt.address;
      _totalAmountCtrl.text = apt.totalAmount.toStringAsFixed(0);
      _paidAmountCtrl.text = apt.paidAmount.toStringAsFixed(0);
      try {
        _dateOfMarriage = DateTime.parse(apt.dateOfMarriage);
      } catch (_) {}

      for (var s in apt.services) {
        if (s.serviceId != null) {
          _selectedServiceIds.add(s.serviceId!);
          if (_servicePriceControllers.containsKey(s.serviceId!)) {
            _servicePriceControllers[s.serviceId!]!.text = s.amount != null ? s.amount!.toStringAsFixed(0) : '';
          }
        }
      }
      setState(() {});
    }
  }

  void _recalculateTotal() {
    double sum = 0.0;
    bool hasPricedServices = false;
    for (var sId in _selectedServiceIds) {
      final text = _servicePriceControllers[sId]?.text.trim() ?? '';
      final val = double.tryParse(text);
      if (val != null && val > 0) {
        sum += val;
        hasPricedServices = true;
      }
    }
    if (hasPricedServices) {
      _totalAmountCtrl.text = sum.toStringAsFixed(0);
    }
    setState(() {});
  }

  Future<void> _pickMarriageDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _dateOfMarriage ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(const Duration(days: 730)),
    );
    if (picked != null) {
      setState(() => _dateOfMarriage = picked);
    }
  }

  Future<void> _saveAppointment() async {
    if (_nameCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Customer Name is required')));
      return;
    }
    if (_mobileCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Mobile Number is required')));
      return;
    }
    if (_dateOfMarriage == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Date of Marriage is required')));
      return;
    }
    if (_addressCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Address is required')));
      return;
    }
    if (_totalAmount <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Total Amount must be greater than ₹0')));
      return;
    }
    if (_paidAmount > _totalAmount) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Paid Amount cannot exceed Total Amount')));
      return;
    }

    // Build services list: Each service has optional price (entered or null)
    List<AppointmentService> selectedServices = [];
    for (var s in _allAvailableServices) {
      if (_selectedServiceIds.contains(s.id)) {
        final priceText = _servicePriceControllers[s.id]?.text.trim() ?? '';
        final parsedPrice = double.tryParse(priceText);
        selectedServices.add(AppointmentService(
          serviceId: s.id,
          serviceName: s.serviceName,
          amount: parsedPrice, // Can be null if left blank
        ));
      }
    }

    final now = DateTime.now();
    final dateStr = DateFormat('yyyy-MM-dd').format(now);
    final timeStr = DateFormat('hh:mm a').format(now);

    String paymentStatus;
    if (_paidAmount == 0) {
      paymentStatus = 'Unpaid';
    } else if (_paidAmount < _totalAmount) {
      paymentStatus = 'Partially Paid';
    } else {
      paymentStatus = 'Paid';
    }

    if (widget.editAppointment != null) {
      final apt = widget.editAppointment!;
      final updated = Appointment(
        id: apt.id,
        appointmentNumber: apt.appointmentNumber,
        customerName: _nameCtrl.text.trim(),
        mobile: _mobileCtrl.text.trim(),
        dateOfMarriage: DateFormat('yyyy-MM-dd').format(_dateOfMarriage!),
        address: _addressCtrl.text.trim(),
        services: selectedServices,
        totalAmount: _totalAmount,
        paidAmount: _paidAmount,
        dueAmount: _dueAmount,
        jobStatus: apt.jobStatus,
        paymentStatus: _dueAmount == 0 ? 'Paid' : (_paidAmount > 0 ? 'Partially Paid' : 'Unpaid'),
        createdAt: apt.createdAt,
        updatedAt: '$dateStr $timeStr',
      );
      await DatabaseHelper.instance.updateAppointment(updated);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Appointment Updated Successfully')));
        Navigator.pop(context, true);
      }
    } else {
      final autoNumber = await DatabaseHelper.instance.getNextAppointmentNumber();
      final newApt = Appointment(
        appointmentNumber: autoNumber,
        customerName: _nameCtrl.text.trim(),
        mobile: _mobileCtrl.text.trim(),
        dateOfMarriage: DateFormat('yyyy-MM-dd').format(_dateOfMarriage!),
        address: _addressCtrl.text.trim(),
        services: selectedServices,
        totalAmount: _totalAmount,
        paidAmount: _paidAmount,
        dueAmount: _dueAmount,
        jobStatus: 'Pending',
        paymentStatus: paymentStatus,
        createdAt: '$dateStr $timeStr',
        updatedAt: '$dateStr $timeStr',
      );
      await DatabaseHelper.instance.createAppointment(newApt);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Appointment Booked Successfully'), backgroundColor: AppTheme.statusGreen),
        );
        Navigator.pop(context, true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEdit = widget.editAppointment != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'Edit Appointment' : 'Book Appointment'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Customer Info Box
            _buildBoxWrapper(
              title: 'Customer Details',
              children: [
                TextField(controller: _nameCtrl, decoration: const InputDecoration(labelText: 'Customer Name *')),
                const SizedBox(height: 12),
                TextField(controller: _mobileCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile Number *')),
                const SizedBox(height: 12),
                ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                  tileColor: Colors.grey.shade50,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: BorderSide(color: Colors.grey.shade200)),
                  title: Text(_dateOfMarriage == null
                      ? 'Select Date of Marriage *'
                      : 'Date of Marriage: ${DateFormat('dd MMM yyyy').format(_dateOfMarriage!)}',
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.calendar_month, color: AppTheme.primaryNavy),
                  onTap: _pickMarriageDate,
                ),
                const SizedBox(height: 12),
                TextField(controller: _addressCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Address *')),
              ],
            ),

            const SizedBox(height: 18),

            // Select Services (Checklist with OPTIONAL price per service)
            _buildBoxWrapper(
              title: 'Select Services (Price Optional)',
              subtitle: 'Select services. Har service ka price daalna optional hai (khali chhod sakte hain).',
              children: [
                if (_allAvailableServices.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Text('Profile me koi service create nahi hai. Niche Total Amount daal kar book karein.'),
                  )
                else
                  ..._allAvailableServices.map((s) {
                    final isSelected = _selectedServiceIds.contains(s.id);
                    return Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.amber.shade50 : Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: isSelected ? AppTheme.accentGold : Colors.grey.shade200),
                      ),
                      child: Row(
                        children: [
                          Checkbox(
                            activeColor: AppTheme.primaryNavy,
                            value: isSelected,
                            onChanged: (val) {
                              setState(() {
                                if (val == true) {
                                  _selectedServiceIds.add(s.id!);
                                } else {
                                  _selectedServiceIds.remove(s.id!);
                                }
                                _recalculateTotal();
                              });
                            },
                          ),
                          Expanded(
                            child: Text(s.serviceName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                          ),
                          if (isSelected)
                            SizedBox(
                              width: 110,
                              height: 40,
                              child: TextField(
                                controller: _servicePriceControllers[s.id],
                                keyboardType: TextInputType.number,
                                decoration: InputDecoration(
                                  hintText: 'Rate (Opt)',
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                                ),
                                onChanged: (_) => _recalculateTotal(),
                              ),
                            ),
                        ],
                      ),
                    );
                  }),
              ],
            ),

            const SizedBox(height: 18),

            // Financial Summary
            _buildBoxWrapper(
              title: 'Final Billing & Advance Amount',
              children: [
                TextField(
                  controller: _totalAmountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Total Bill Amount (₹) *'),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _paidAmountCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Advance / Paid Amount (₹)'),
                  onChanged: (_) => setState(() {}),
                ),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _dueAmount > 0 ? Colors.red.shade50 : Colors.green.shade50,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _dueAmount > 0 ? Colors.red.shade200 : Colors.green.shade200),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Remaining Due:', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                      Text(
                        '₹${_dueAmount.toStringAsFixed(0)}',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w900,
                          color: _dueAmount > 0 ? AppTheme.statusRed : AppTheme.statusGreen,
                        ),
                      ),
                    ],
                  ),
                ),
                if (!isEdit && _paidAmount > 0) ...[
                  const SizedBox(height: 14),
                  const Text('Payment Mode *', style: TextStyle(fontWeight: FontWeight.bold)),
                  Row(
                    children: [
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('Cash'),
                          value: 'Cash',
                          groupValue: _paymentMethod,
                          onChanged: (v) => setState(() => _paymentMethod = v!),
                        ),
                      ),
                      Expanded(
                        child: RadioListTile<String>(
                          title: const Text('UPI'),
                          value: 'UPI',
                          groupValue: _paymentMethod,
                          onChanged: (v) => setState(() => _paymentMethod = v!),
                        ),
                      ),
                    ],
                  ),
                  if (_paymentMethod == 'UPI')
                    TextField(
                      controller: _upiTxnCtrl,
                      decoration: const InputDecoration(labelText: 'UPI Reference ID (Optional)'),
                    ),
                ],
              ],
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: _saveAppointment,
                child: Text(isEdit ? 'Update Appointment' : 'Book Appointment', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildBoxWrapper({required String title, String? subtitle, required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.primaryNavy)),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle, style: TextStyle(fontSize: 12, color: Colors.grey.shade500)),
          ],
          const Divider(height: 24),
          ...children,
        ],
      ),
    );
  }
}
