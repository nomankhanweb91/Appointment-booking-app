import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../../models/app_models.dart';
import '../../services/database/db_helper.dart';
import '../../theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  final VoidCallback onProfileUpdated;
  const ProfileScreen({super.key, required this.onProfileUpdated});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  BusinessProfile _profile = BusinessProfile();

  // App Header
  final _appStoreNameCtrl = TextEditingController();
  String _appLogoPath = '';

  // Bill Header
  final _billStoreNameCtrl = TextEditingController();
  final _contactCtrl = TextEditingController();
  final _waCtrl = TextEditingController();
  final _addressCtrl = TextEditingController();
  String _billLogoPath = '';

  List<OfferModel> _offers = [];
  List<ServiceModel> _services = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _loadAllProfileData();
  }

  Future<void> _loadAllProfileData() async {
    final p = await DatabaseHelper.instance.getProfile();
    final o = await DatabaseHelper.instance.getOffers();
    final s = await DatabaseHelper.instance.getServices();

    setState(() {
      _profile = p;
      _appStoreNameCtrl.text = p.storeName;
      _appLogoPath = p.appLogo;

      _billStoreNameCtrl.text = p.billStoreName;
      _contactCtrl.text = p.contact;
      _waCtrl.text = p.whatsapp;
      _addressCtrl.text = p.address;
      _billLogoPath = p.billLogo;

      _offers = o;
      _services = s;
    });
  }

  Future<void> _pickImage(Function(String) onPicked) async {
    final picker = ImagePicker();
    final picked = await picker.pickImage(source: ImageSource.gallery);
    if (picked != null) {
      onPicked(picked.path);
    }
  }

  Future<void> _saveHeaders() async {
    final updated = BusinessProfile(
      appLogo: _appLogoPath,
      storeName: _appStoreNameCtrl.text.trim(),
      billLogo: _billLogoPath,
      billStoreName: _billStoreNameCtrl.text.trim(),
      contact: _contactCtrl.text.trim(),
      whatsapp: _waCtrl.text.trim(),
      address: _addressCtrl.text.trim(),
    );
    await DatabaseHelper.instance.saveProfile(updated);
    widget.onProfileUpdated();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Settings saved successfully!')));
  }

  void _openOfferDialog({OfferModel? offer}) {
    final offerCtrl = TextEditingController(text: offer?.offerText ?? '');
    final contactCtrl = TextEditingController(text: offer?.contact ?? '');
    final waCtrl = TextEditingController(text: offer?.whatsapp ?? '');
    String bannerPath = offer?.banner ?? '';

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: Text(offer == null ? '+ Add Offer / Promotion' : 'Edit Offer'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(controller: offerCtrl, decoration: const InputDecoration(labelText: 'Offer Text *')),
                const SizedBox(height: 10),
                TextField(controller: contactCtrl, decoration: const InputDecoration(labelText: 'Contact Number')),
                const SizedBox(height: 10),
                TextField(controller: waCtrl, decoration: const InputDecoration(labelText: 'WhatsApp Number')),
                const SizedBox(height: 14),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add_photo_alternate),
                  label: Text(bannerPath.isNotEmpty ? 'Change Banner Image' : 'Upload Banner Image'),
                  style: ElevatedButton.styleFrom(backgroundColor: AppTheme.primaryNavy),
                  onPressed: () => _pickImage((path) => setDialogState(() => bannerPath = path)),
                ),
                if (bannerPath.isNotEmpty && File(bannerPath).existsSync()) ...[
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.file(File(bannerPath), height: 100, width: double.infinity, fit: BoxFit.cover),
                  ),
                ],
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
            ElevatedButton(
              onPressed: () async {
                if (offerCtrl.text.trim().isEmpty) return;
                if (offer == null) {
                  await DatabaseHelper.instance.addOffer(OfferModel(
                    offerText: offerCtrl.text.trim(),
                    contact: contactCtrl.text.trim(),
                    whatsapp: waCtrl.text.trim(),
                    banner: bannerPath,
                    isActive: 1,
                  ));
                } else {
                  await DatabaseHelper.instance.updateOffer(OfferModel(
                    id: offer.id,
                    offerText: offerCtrl.text.trim(),
                    contact: contactCtrl.text.trim(),
                    whatsapp: waCtrl.text.trim(),
                    banner: bannerPath,
                    isActive: offer.isActive,
                  ));
                }
                Navigator.pop(ctx);
                _loadAllProfileData();
              },
              child: const Text('Save Offer'),
            ),
          ],
        ),
      ),
    );
  }

  void _openServiceDialog({ServiceModel? service}) {
    final nameCtrl = TextEditingController(text: service?.serviceName ?? '');
    final priceCtrl = TextEditingController(text: service?.servicePrice != null ? service!.servicePrice!.toStringAsFixed(0) : '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: Text(service == null ? '+ Add Service' : 'Edit Service'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: 'Service Name *')),
            const SizedBox(height: 10),
            TextField(controller: priceCtrl, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Service Price (₹) — Optional')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () async {
              if (nameCtrl.text.trim().isEmpty) return;
              final price = double.tryParse(priceCtrl.text.trim());
              if (service == null) {
                await DatabaseHelper.instance.addService(ServiceModel(
                  serviceName: nameCtrl.text.trim(),
                  servicePrice: price,
                  isActive: 1,
                ));
              } else {
                await DatabaseHelper.instance.updateService(ServiceModel(
                  id: service.id,
                  serviceName: nameCtrl.text.trim(),
                  servicePrice: price,
                  isActive: service.isActive,
                ));
              }
              Navigator.pop(ctx);
              _loadAllProfileData();
            },
            child: const Text('Save Service'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings & Profile'),
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelColor: AppTheme.primaryNavy,
          indicatorColor: AppTheme.accentGold,
          indicatorWeight: 3,
          labelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14),
          tabs: const [
            Tab(text: 'App Header'),
            Tab(text: 'Bill Header'),
            Tab(text: 'Offers / Ads'),
            Tab(text: 'Service List'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 1. App Header Tab
          SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeaderInfoBox('Top App Bar Customization', 'Set your parlour name and custom icon visible in the application header.'),
                const SizedBox(height: 16),
                TextField(controller: _appStoreNameCtrl, decoration: const InputDecoration(labelText: 'Store Name')),
                const SizedBox(height: 18),
                Row(
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.image),
                      label: const Text('Upload App Logo'),
                      onPressed: () => _pickImage((p) => setState(() => _appLogoPath = p)),
                    ),
                    const SizedBox(width: 14),
                    if (_appLogoPath.isNotEmpty && File(_appLogoPath).existsSync())
                      ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(_appLogoPath), width: 55, height: 55, fit: BoxFit.cover)),
                  ],
                ),
                const SizedBox(height: 40),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(onPressed: _saveHeaders, child: const Text('Save App Header')),
                )
              ],
            ),
          ),

          // 2. Bill Header Tab
          SingleChildScrollView(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeaderInfoBox('Printed Invoice Header', 'Details entered here appear directly on the PDF invoices.'),
                const SizedBox(height: 16),
                TextField(controller: _billStoreNameCtrl, decoration: const InputDecoration(labelText: 'Store Name (Printed on Bill)')),
                const SizedBox(height: 12),
                TextField(controller: _contactCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Contact Number')),
                const SizedBox(height: 12),
                TextField(controller: _waCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp Number')),
                const SizedBox(height: 12),
                TextField(controller: _addressCtrl, maxLines: 2, decoration: const InputDecoration(labelText: 'Store Address')),
                const SizedBox(height: 18),
                Row(
                  children: [
                    ElevatedButton.icon(
                      icon: const Icon(Icons.image),
                      label: const Text('Upload Bill Logo'),
                      onPressed: () => _pickImage((p) => setState(() => _billLogoPath = p)),
                    ),
                    const SizedBox(width: 14),
                    if (_billLogoPath.isNotEmpty && File(_billLogoPath).existsSync())
                      ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.file(File(_billLogoPath), width: 55, height: 55, fit: BoxFit.cover)),
                  ],
                ),
                const SizedBox(height: 30),
                SizedBox(
                  width: double.infinity,
                  height: 50,
                  child: ElevatedButton(onPressed: _saveHeaders, child: const Text('Save Bill Header')),
                )
              ],
            ),
          ),

          // 3. Offers / Ads Tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.add_photo_alternate),
                    label: const Text('+ Add Offer / Banner'),
                    onPressed: () => _openOfferDialog(),
                  ),
                ),
                const SizedBox(height: 14),
                Expanded(
                  child: _offers.isEmpty
                      ? const Center(child: Text('No offers added yet.'))
                      : ListView.builder(
                          itemCount: _offers.length,
                          itemBuilder: (context, idx) {
                            final o = _offers[idx];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  if (o.banner.isNotEmpty && File(o.banner).existsSync())
                                    ClipRRect(
                                      borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                                      child: Image.file(File(o.banner), height: 120, width: double.infinity, fit: BoxFit.cover),
                                    ),
                                  ListTile(
                                    title: Text(o.offerText, style: const TextStyle(fontWeight: FontWeight.w800)),
                                    subtitle: Text('Contact: ${o.contact} | WA: ${o.whatsapp}'),
                                    trailing: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Switch(
                                          activeColor: AppTheme.accentGold,
                                          value: o.isActive == 1,
                                          onChanged: (val) async {
                                            await DatabaseHelper.instance.updateOffer(OfferModel(
                                              id: o.id,
                                              offerText: o.offerText,
                                              banner: o.banner,
                                              contact: o.contact,
                                              whatsapp: o.whatsapp,
                                              isActive: val ? 1 : 0,
                                            ));
                                            _loadAllProfileData();
                                          },
                                        ),
                                        IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () => _openOfferDialog(offer: o)),
                                        IconButton(
                                          icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                          onPressed: () async {
                                            await DatabaseHelper.instance.deleteOffer(o.id!);
                                            _loadAllProfileData();
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                )
              ],
            ),
          ),

          // 4. Service List Tab
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.add),
                    label: const Text('+ Add New Service'),
                    onPressed: () => _openServiceDialog(),
                  ),
                ),
                const SizedBox(height: 14),
                Expanded(
                  child: _services.isEmpty
                      ? const Center(child: Text('No Services Added Yet'))
                      : ListView.builder(
                          itemCount: _services.length,
                          itemBuilder: (context, idx) {
                            final s = _services[idx];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 10),
                              child: ListTile(
                                title: Text(s.serviceName, style: const TextStyle(fontWeight: FontWeight.w800)),
                                subtitle: Text(s.servicePrice != null ? '₹${s.servicePrice!.toStringAsFixed(0)}' : 'Price not set (Manual)'),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Switch(
                                      activeColor: AppTheme.accentGold,
                                      value: s.isActive == 1,
                                      onChanged: (val) async {
                                        await DatabaseHelper.instance.updateService(ServiceModel(
                                          id: s.id,
                                          serviceName: s.serviceName,
                                          servicePrice: s.servicePrice,
                                          isActive: val ? 1 : 0,
                                        ));
                                        _loadAllProfileData();
                                      },
                                    ),
                                    IconButton(icon: const Icon(Icons.edit, size: 20), onPressed: () => _openServiceDialog(service: s)),
                                    IconButton(
                                      icon: const Icon(Icons.delete, color: Colors.red, size: 20),
                                      onPressed: () async {
                                        await DatabaseHelper.instance.deleteService(s.id!);
                                        _loadAllProfileData();
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeaderInfoBox(String title, String desc) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.primaryNavy.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.primaryNavy.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppTheme.primaryNavy, fontSize: 14)),
          const SizedBox(height: 4),
          Text(desc, style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
        ],
      ),
    );
  }
}
