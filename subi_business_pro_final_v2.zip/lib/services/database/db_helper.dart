import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../models/app_models.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('subi_business_clean_v3.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE profile (
        id INTEGER PRIMARY KEY,
        appLogo TEXT,
        storeName TEXT,
        billLogo TEXT,
        billStoreName TEXT,
        contact TEXT,
        whatsapp TEXT,
        address TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE services (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        serviceName TEXT NOT NULL,
        servicePrice REAL,
        isActive INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE offers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        offerText TEXT NOT NULL,
        banner TEXT,
        contact TEXT,
        whatsapp TEXT,
        isActive INTEGER DEFAULT 1
      )
    ''');

    await db.execute('''
      CREATE TABLE appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        appointmentNumber TEXT UNIQUE NOT NULL,
        customerName TEXT NOT NULL,
        mobile TEXT NOT NULL,
        dateOfMarriage TEXT NOT NULL,
        address TEXT NOT NULL,
        servicesJson TEXT,
        totalAmount REAL NOT NULL,
        paidAmount REAL NOT NULL,
        dueAmount REAL NOT NULL,
        jobStatus TEXT NOT NULL,
        paymentStatus TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE store_bills (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        billNumber TEXT UNIQUE NOT NULL,
        customerName TEXT NOT NULL,
        mobile TEXT NOT NULL,
        itemsJson TEXT NOT NULL,
        totalAmount REAL NOT NULL,
        paidAmount REAL NOT NULL,
        dueAmount REAL NOT NULL,
        paymentStatus TEXT NOT NULL,
        createdAt TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      )
    ''');

    // Default seeded profile
    await db.insert('profile', BusinessProfile().toMap());

    // Default starter services
    await db.insert('services', {'serviceName': 'Bridal Makeup', 'servicePrice': 5000.0, 'isActive': 1});
    await db.insert('services', {'serviceName': 'Pre-Bridal Package', 'servicePrice': 3500.0, 'isActive': 1});
    await db.insert('services', {'serviceName': 'Party Makeup', 'servicePrice': 2500.0, 'isActive': 1});
    await db.insert('services', {'serviceName': 'Hair Styling & Spa', 'servicePrice': 1500.0, 'isActive': 1});
    await db.insert('services', {'serviceName': 'Facial & Glow Cleanup', 'servicePrice': 999.0, 'isActive': 1});
    await db.insert('services', {'serviceName': 'Mehndi Art', 'servicePrice': 1000.0, 'isActive': 1});

    // Default starter offer
    await db.insert('offers', {
      'offerText': 'Wedding Special: Flat 20% OFF on Complete Bridal Booking!',
      'banner': '',
      'contact': '9876543210',
      'whatsapp': '9876543210',
      'isActive': 1
    });
  }

  // --- Auto Generate Number ---
  Future<String> getNextAppointmentNumber() async {
    final db = await database;
    final res = await db.rawQuery('SELECT COUNT(*) as cnt FROM appointments');
    int count = Sqflite.firstIntValue(res) ?? 0;
    return 'APT-${(count + 1).toString().padLeft(5, '0')}';
  }

  Future<String> getNextStoreBillNumber() async {
    final db = await database;
    final res = await db.rawQuery('SELECT COUNT(*) as cnt FROM store_bills');
    int count = Sqflite.firstIntValue(res) ?? 0;
    return 'STR-${(count + 1).toString().padLeft(5, '0')}';
  }

  // --- Profile ---
  Future<BusinessProfile> getProfile() async {
    final db = await database;
    final res = await db.query('profile', where: 'id = 1');
    if (res.isNotEmpty) return BusinessProfile.fromMap(res.first);
    return BusinessProfile();
  }

  Future<void> saveProfile(BusinessProfile p) async {
    final db = await database;
    await db.insert('profile', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // --- Services ---
  Future<List<ServiceModel>> getServices({bool activeOnly = false}) async {
    final db = await database;
    final res = await db.query(
      'services',
      where: activeOnly ? 'isActive = 1' : null,
      orderBy: 'id DESC',
    );
    return res.map((e) => ServiceModel.fromMap(e)).toList();
  }

  Future<int> addService(ServiceModel s) async => (await database).insert('services', s.toMap());
  Future<int> updateService(ServiceModel s) async =>
      (await database).update('services', s.toMap(), where: 'id = ?', whereArgs: [s.id]);
  Future<int> deleteService(int id) async =>
      (await database).delete('services', where: 'id = ?', whereArgs: [id]);

  // --- Offers (Multiple Banners & Offers) ---
  Future<List<OfferModel>> getOffers({bool activeOnly = false}) async {
    final db = await database;
    final res = await db.query(
      'offers',
      where: activeOnly ? 'isActive = 1' : null,
      orderBy: 'id DESC',
    );
    return res.map((e) => OfferModel.fromMap(e)).toList();
  }

  Future<int> addOffer(OfferModel o) async => (await database).insert('offers', o.toMap());
  Future<int> updateOffer(OfferModel o) async =>
      (await database).update('offers', o.toMap(), where: 'id = ?', whereArgs: [o.id]);
  Future<int> deleteOffer(int id) async =>
      (await database).delete('offers', where: 'id = ?', whereArgs: [id]);

  // --- Appointments with Marriage Date Priority Sorting ---
  Future<int> createAppointment(Appointment a) async => (await database).insert('appointments', a.toMap());

  Future<List<Appointment>> getAppointments({String query = '', String statusFilter = 'All'}) async {
    final db = await database;
    String? where;
    List<dynamic> args = [];

    if (query.isNotEmpty) {
      where = '(customerName LIKE ? OR mobile LIKE ? OR appointmentNumber LIKE ? OR address LIKE ?)';
      args.addAll(['%$query%', '%$query%', '%$query%', '%$query%']);
    }

    if (statusFilter != 'All') {
      where = where == null ? 'paymentStatus = ?' : '$where AND paymentStatus = ?';
      args.add(statusFilter);
    }

    final res = await db.query('appointments', where: where, whereArgs: args);
    List<Appointment> list = res.map((e) => Appointment.fromMap(e)).toList();

    // Upcoming Priority Logic
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    list.sort((a, b) {
      DateTime dateA;
      DateTime dateB;
      try {
        dateA = DateTime.parse(a.dateOfMarriage);
      } catch (_) {
        dateA = today;
      }
      try {
        dateB = DateTime.parse(b.dateOfMarriage);
      } catch (_) {
        dateB = today;
      }

      final diffA = dateA.difference(today).inDays;
      final diffB = dateB.difference(today).inDays;

      bool isPastA = diffA < 0;
      bool isPastB = diffB < 0;

      if (!isPastA && !isPastB) {
        return diffA.compareTo(diffB); // Upcoming nearest first
      } else if (!isPastA && isPastB) {
        return -1; // Upcoming always above past
      } else if (isPastA && !isPastB) {
        return 1;
      } else {
        return diffB.compareTo(diffA); // Latest past first
      }
    });

    return list;
  }

  Future<Appointment?> getAppointmentById(int id) async {
    final db = await database;
    final res = await db.query('appointments', where: 'id = ?', whereArgs: [id]);
    return res.isNotEmpty ? Appointment.fromMap(res.first) : null;
  }

  Future<int> updateAppointment(Appointment a) async =>
      (await database).update('appointments', a.toMap(), where: 'id = ?', whereArgs: [a.id]);

  Future<int> deleteAppointment(int id) async =>
      (await database).delete('appointments', where: 'id = ?', whereArgs: [id]);

  // --- Store Bills ---
  Future<int> createStoreBill(StoreBill b) async => (await database).insert('store_bills', b.toMap());

  Future<List<StoreBill>> getStoreBills({String query = '', String statusFilter = 'All'}) async {
    final db = await database;
    String? where;
    List<dynamic> args = [];

    if (query.isNotEmpty) {
      where = '(customerName LIKE ? OR mobile LIKE ? OR billNumber LIKE ? OR itemsJson LIKE ?)';
      args.addAll(['%$query%', '%$query%', '%$query%', '%$query%']);
    }

    if (statusFilter != 'All') {
      where = where == null ? 'paymentStatus = ?' : '$where AND paymentStatus = ?';
      args.add(statusFilter);
    }

    final res = await db.query('store_bills', where: where, whereArgs: args, orderBy: 'id DESC');
    return res.map((e) => StoreBill.fromMap(e)).toList();
  }

  Future<StoreBill?> getStoreBillById(int id) async {
    final db = await database;
    final res = await db.query('store_bills', where: 'id = ?', whereArgs: [id]);
    return res.isNotEmpty ? StoreBill.fromMap(res.first) : null;
  }

  Future<int> updateStoreBill(StoreBill b) async =>
      (await database).update('store_bills', b.toMap(), where: 'id = ?', whereArgs: [b.id]);

  Future<int> deleteStoreBill(int id) async =>
      (await database).delete('store_bills', where: 'id = ?', whereArgs: [id]);

  // --- Metrics ---
  Future<Map<String, dynamic>> getDashboardMetrics() async {
    final db = await database;
    final aptCounts = await db.rawQuery('SELECT COUNT(*) as count FROM appointments');
    final billCounts = await db.rawQuery('SELECT COUNT(*) as count FROM store_bills');
    final aptFinances = await db.rawQuery('SELECT SUM(paidAmount) as paid, SUM(dueAmount) as due FROM appointments');

    return {
      'totalAppointments': Sqflite.firstIntValue(aptCounts) ?? 0,
      'totalStoreBills': Sqflite.firstIntValue(billCounts) ?? 0,
      'totalDueAmount': (aptFinances.first['due'] as num?)?.toDouble() ?? 0.0,
      'totalPaidAmount': (aptFinances.first['paid'] as num?)?.toDouble() ?? 0.0,
    };
  }
}
