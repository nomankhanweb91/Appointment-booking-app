import 'dart:io';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../../models/app_models.dart';
import '../database/db_helper.dart';

class PdfInvoiceService {
  static Future<void> printAppointmentBill({required Appointment appointment}) async {
    final profile = await DatabaseHelper.instance.getProfile();
    final offers = await DatabaseHelper.instance.getOffers(activeOnly: true);
    final pdf = pw.Document();

    pw.MemoryImage? logoImage;
    if (profile.billLogo.isNotEmpty && File(profile.billLogo).existsSync()) {
      try {
        logoImage = pw.MemoryImage(File(profile.billLogo).readAsBytesSync());
      } catch (_) {}
    }

    List<Map<String, dynamic>> offerBannerImages = [];
    for (var o in offers) {
      pw.MemoryImage? bannerImg;
      if (o.banner.isNotEmpty && File(o.banner).existsSync()) {
        try {
          bannerImg = pw.MemoryImage(File(o.banner).readAsBytesSync());
        } catch (_) {}
      }
      offerBannerImages.add({'model': o, 'image': bannerImg});
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) => [
          _buildHeader(profile, logoImage, 'APPOINTMENT INVOICE'),
          pw.SizedBox(height: 14),
          _buildAppointmentDetails(appointment),
          pw.SizedBox(height: 14),
          if (appointment.services.isNotEmpty) ...[
            _buildServicesTable(appointment.services),
            pw.SizedBox(height: 12),
          ],
          _buildPaymentSummary(
            total: appointment.totalAmount,
            paid: appointment.paidAmount,
            due: appointment.dueAmount,
            status: appointment.paymentStatus,
          ),
          pw.Spacer(),
          if (offerBannerImages.isNotEmpty) ...[
            _buildOffersWithBannersSection(offerBannerImages),
            pw.SizedBox(height: 10),
          ],
          _buildThankYouFooter(profile),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
      name: '${appointment.appointmentNumber}_Bill.pdf',
    );
  }

  static Future<void> printStoreBill({required StoreBill bill}) async {
    final profile = await DatabaseHelper.instance.getProfile();
    final offers = await DatabaseHelper.instance.getOffers(activeOnly: true);
    final pdf = pw.Document();

    pw.MemoryImage? logoImage;
    if (profile.billLogo.isNotEmpty && File(profile.billLogo).existsSync()) {
      try {
        logoImage = pw.MemoryImage(File(profile.billLogo).readAsBytesSync());
      } catch (_) {}
    }

    List<Map<String, dynamic>> offerBannerImages = [];
    for (var o in offers) {
      pw.MemoryImage? bannerImg;
      if (o.banner.isNotEmpty && File(o.banner).existsSync()) {
        try {
          bannerImg = pw.MemoryImage(File(o.banner).readAsBytesSync());
        } catch (_) {}
      }
      offerBannerImages.add({'model': o, 'image': bannerImg});
    }

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) => [
          _buildHeader(profile, logoImage, 'RETAIL STORE INVOICE'),
          pw.SizedBox(height: 14),
          _buildStoreDetails(bill),
          pw.SizedBox(height: 14),
          _buildStoreItemsTable(bill.items),
          pw.SizedBox(height: 12),
          _buildPaymentSummary(
            total: bill.totalAmount,
            paid: bill.paidAmount,
            due: bill.dueAmount,
            status: bill.paymentStatus,
          ),
          pw.Spacer(),
          if (offerBannerImages.isNotEmpty) ...[
            _buildOffersWithBannersSection(offerBannerImages),
            pw.SizedBox(height: 10),
          ],
          _buildThankYouFooter(profile),
        ],
      ),
    );

    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
      name: '${bill.billNumber}_Invoice.pdf',
    );
  }

  static pw.Widget _buildHeader(BusinessProfile profile, pw.MemoryImage? logo, String title) {
    return pw.Column(
      children: [
        pw.Row(
          mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    profile.billStoreName.isNotEmpty ? profile.billStoreName : 'Subi Beauty Parlour',
                    style: pw.TextStyle(fontSize: 22, fontWeight: pw.FontWeight.bold, color: PdfColors.blue900),
                  ),
                  if (profile.address.isNotEmpty)
                    pw.Text('Address: ${profile.address}', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
                  pw.Text(
                    'Contact: ${profile.contact}  |  WhatsApp: ${profile.whatsapp}',
                    style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700),
                  ),
                ],
              ),
            ),
            if (logo != null)
              pw.Container(
                width: 60,
                height: 60,
                margin: const pw.EdgeInsets.only(left: 10),
                child: pw.Image(logo, fit: pw.BoxFit.contain),
              ),
          ],
        ),
        pw.SizedBox(height: 8),
        pw.Container(
          width: double.infinity,
          padding: const pw.EdgeInsets.symmetric(vertical: 4),
          color: PdfColors.blue900,
          child: pw.Center(
            child: pw.Text(
              title,
              style: pw.TextStyle(color: PdfColors.white, fontSize: 11, fontWeight: pw.FontWeight.bold),
            ),
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildAppointmentDetails(Appointment apt) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Customer: ${apt.customerName}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
              pw.Text('Phone: ${apt.mobile}', style: const pw.TextStyle(fontSize: 10)),
              pw.Text('Address: ${apt.address}', style: const pw.TextStyle(fontSize: 10)),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text('Invoice No: ${apt.appointmentNumber}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11, color: PdfColors.blue900)),
              pw.Text('Marriage Date: ${apt.dateOfMarriage}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10, color: PdfColors.pink700)),
              pw.Text('Booking Date: ${apt.createdAt}', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildStoreDetails(StoreBill bill) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(10),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: PdfColors.grey300),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text('Customer: ${bill.customerName}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
              pw.Text('Mobile: ${bill.mobile}', style: const pw.TextStyle(fontSize: 10)),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text('Bill Number: ${bill.billNumber}', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11, color: PdfColors.blue900)),
              pw.Text('Date: ${bill.createdAt}', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600)),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildServicesTable(List<AppointmentService> services) {
    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey300),
      columnWidths: {
        0: const pw.FlexColumnWidth(1),
        1: const pw.FlexColumnWidth(5),
        2: const pw.FlexColumnWidth(2),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey200),
          children: [
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('#', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Service Description', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Amount (INR)', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
          ],
        ),
        ...services.asMap().entries.map(
              (e) => pw.TableRow(
                children: [
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('${e.key + 1}', style: const pw.TextStyle(fontSize: 9))),
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text(e.value.serviceName, style: const pw.TextStyle(fontSize: 9))),
                  pw.Padding(
                    padding: const pw.EdgeInsets.all(6),
                    child: pw.Text(
                      e.value.amount != null ? 'Rs. ${e.value.amount!.toStringAsFixed(2)}' : 'Included',
                      textAlign: pw.TextAlign.right,
                      style: const pw.TextStyle(fontSize: 9),
                    ),
                  ),
                ],
              ),
            ),
      ],
    );
  }

  static pw.Widget _buildStoreItemsTable(List<StoreBillItem> items) {
    double total = items.fold(0.0, (sum, i) => sum + i.itemPrice);
    return pw.Table(
      border: pw.TableBorder.all(color: PdfColors.grey300),
      columnWidths: {
        0: const pw.FlexColumnWidth(1),
        1: const pw.FlexColumnWidth(5),
        2: const pw.FlexColumnWidth(2),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey200),
          children: [
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('#', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Item Description', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Price (INR)', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
          ],
        ),
        ...items.asMap().entries.map(
              (e) => pw.TableRow(
                children: [
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('${e.key + 1}', style: const pw.TextStyle(fontSize: 9))),
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text(e.value.itemName, style: const pw.TextStyle(fontSize: 9))),
                  pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Rs. ${e.value.itemPrice.toStringAsFixed(2)}', textAlign: pw.TextAlign.right, style: const pw.TextStyle(fontSize: 9))),
                ],
              ),
            ),
        pw.TableRow(
          decoration: const pw.BoxDecoration(color: PdfColors.grey100),
          children: [
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('')),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Items Total', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
            pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text('Rs. ${total.toStringAsFixed(2)}', textAlign: pw.TextAlign.right, style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10))),
          ],
        ),
      ],
    );
  }

  static pw.Widget _buildPaymentSummary({
    required double total,
    required double paid,
    required double due,
    required String status,
  }) {
    return pw.Align(
      alignment: pw.Alignment.centerRight,
      child: pw.Container(
        width: 240,
        padding: const pw.EdgeInsets.all(8),
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: PdfColors.grey300),
          borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
          color: PdfColors.grey50,
        ),
        child: pw.Column(
          children: [
            _summaryRow('Total Amount:', 'Rs. ${total.toStringAsFixed(2)}', isBold: true),
            _summaryRow('Total Paid:', 'Rs. ${paid.toStringAsFixed(2)}', color: PdfColors.green700),
            pw.Divider(thickness: 0.5),
            _summaryRow('Remaining Due:', 'Rs. ${due.toStringAsFixed(2)}', isBold: true, color: due > 0 ? PdfColors.red700 : PdfColors.green700),
            _summaryRow('Payment Status:', status, isBold: true),
          ],
        ),
      ),
    );
  }

  static pw.Widget _summaryRow(String label, String val, {bool isBold = false, PdfColor? color}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label, style: pw.TextStyle(fontSize: 10, fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal)),
          pw.Text(val, style: pw.TextStyle(fontSize: 10, fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color)),
        ],
      ),
    );
  }

  static pw.Widget _buildOffersWithBannersSection(List<Map<String, dynamic>> offerBannerList) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('SPECIAL OFFERS & PROMOTIONS', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: PdfColors.pink900)),
        pw.SizedBox(height: 4),
        pw.Row(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: offerBannerList.take(3).map((item) {
            final OfferModel o = item['model'];
            final pw.MemoryImage? bannerImg = item['image'];
            return pw.Expanded(
              child: pw.Container(
                margin: const pw.EdgeInsets.symmetric(horizontal: 2),
                padding: const pw.EdgeInsets.all(6),
                decoration: pw.BoxDecoration(
                  border: pw.Border.all(color: PdfColors.pink200),
                  borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
                  color: PdfColors.pink50,
                ),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    if (bannerImg != null) ...[
                      pw.Container(
                        height: 45,
                        width: double.infinity,
                        margin: const pw.EdgeInsets.only(bottom: 4),
                        child: pw.Image(bannerImg, fit: pw.BoxFit.cover),
                      ),
                    ],
                    pw.Text(o.offerText, style: pw.TextStyle(fontSize: 8, fontWeight: pw.FontWeight.bold, color: PdfColors.grey900)),
                    if (o.whatsapp.isNotEmpty)
                      pw.Text('WA: ${o.whatsapp}', style: const pw.TextStyle(fontSize: 7, color: PdfColors.green800)),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  static pw.Widget _buildThankYouFooter(BusinessProfile profile) {
    return pw.Center(
      child: pw.Text(
        'Thank you for visiting ${profile.billStoreName.isNotEmpty ? profile.billStoreName : 'Subi Beauty Parlour'}! Visit again.',
        style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey600),
      ),
    );
  }
}
