import 'dart:convert';

class AppointmentService {
  final int? serviceId;
  final String serviceName;
  final double? amount; // Optional: price entered or null

  AppointmentService({
    this.serviceId,
    required this.serviceName,
    this.amount,
  });

  Map<String, dynamic> toMap() => {
        'serviceId': serviceId,
        'serviceName': serviceName,
        'amount': amount,
      };

  factory AppointmentService.fromMap(Map<String, dynamic> map) => AppointmentService(
        serviceId: map['serviceId'],
        serviceName: map['serviceName'] ?? '',
        amount: map['amount'] != null ? (map['amount'] as num).toDouble() : null,
      );
}

class Appointment {
  final int? id;
  final String appointmentNumber;
  final String customerName;
  final String mobile;
  final String dateOfMarriage;
  final String address;
  final List<AppointmentService> services; // Services list (Price per service is completely optional)
  final double totalAmount;
  final double paidAmount;
  final double dueAmount;
  final String jobStatus; 
  final String paymentStatus; 
  final String createdAt;
  final String updatedAt;

  Appointment({
    this.id,
    required this.appointmentNumber,
    required this.customerName,
    required this.mobile,
    required this.dateOfMarriage,
    required this.address,
    required this.services,
    required this.totalAmount,
    required this.paidAmount,
    required this.dueAmount,
    required this.jobStatus,
    required this.paymentStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'appointmentNumber': appointmentNumber,
        'customerName': customerName,
        'mobile': mobile,
        'dateOfMarriage': dateOfMarriage,
        'address': address,
        'servicesJson': jsonEncode(services.map((s) => s.toMap()).toList()),
        'totalAmount': totalAmount,
        'paidAmount': paidAmount,
        'dueAmount': dueAmount,
        'jobStatus': jobStatus,
        'paymentStatus': paymentStatus,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };

  factory Appointment.fromMap(Map<String, dynamic> map) {
    List<AppointmentService> svcList = [];
    if (map['servicesJson'] != null && map['servicesJson'].toString().isNotEmpty) {
      try {
        final List decoded = jsonDecode(map['servicesJson']);
        svcList = decoded.map((e) => AppointmentService.fromMap(e)).toList();
      } catch (_) {}
    }
    return Appointment(
      id: map['id'],
      appointmentNumber: map['appointmentNumber'],
      customerName: map['customerName'],
      mobile: map['mobile'],
      dateOfMarriage: map['dateOfMarriage'],
      address: map['address'],
      services: svcList,
      totalAmount: (map['totalAmount'] as num).toDouble(),
      paidAmount: (map['paidAmount'] as num).toDouble(),
      dueAmount: (map['dueAmount'] as num).toDouble(),
      jobStatus: map['jobStatus'] ?? 'Pending',
      paymentStatus: map['paymentStatus'] ?? 'Unpaid',
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
    );
  }
}

class StoreBillItem {
  final String itemName;
  final double itemPrice;

  StoreBillItem({required this.itemName, required this.itemPrice});

  Map<String, dynamic> toMap() => {'itemName': itemName, 'itemPrice': itemPrice};
  factory StoreBillItem.fromMap(Map<String, dynamic> map) =>
      StoreBillItem(itemName: map['itemName'] ?? '', itemPrice: (map['itemPrice'] as num).toDouble());
}

class StoreBill {
  final int? id;
  final String billNumber;
  final String customerName;
  final String mobile;
  final List<StoreBillItem> items;
  final double totalAmount;
  final double paidAmount;
  final double dueAmount;
  final String paymentStatus;
  final String createdAt;
  final String updatedAt;

  StoreBill({
    this.id,
    required this.billNumber,
    required this.customerName,
    required this.mobile,
    required this.items,
    required this.totalAmount,
    required this.paidAmount,
    required this.dueAmount,
    required this.paymentStatus,
    required this.createdAt,
    required this.updatedAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'billNumber': billNumber,
        'customerName': customerName,
        'mobile': mobile,
        'itemsJson': jsonEncode(items.map((i) => i.toMap()).toList()),
        'totalAmount': totalAmount,
        'paidAmount': paidAmount,
        'dueAmount': dueAmount,
        'paymentStatus': paymentStatus,
        'createdAt': createdAt,
        'updatedAt': updatedAt,
      };

  factory StoreBill.fromMap(Map<String, dynamic> map) {
    List<StoreBillItem> itemList = [];
    if (map['itemsJson'] != null && map['itemsJson'].toString().isNotEmpty) {
      try {
        final List decoded = jsonDecode(map['itemsJson']);
        itemList = decoded.map((e) => StoreBillItem.fromMap(e)).toList();
      } catch (_) {}
    }
    return StoreBill(
      id: map['id'],
      billNumber: map['billNumber'],
      customerName: map['customerName'],
      mobile: map['mobile'],
      items: itemList,
      totalAmount: (map['totalAmount'] as num).toDouble(),
      paidAmount: (map['paidAmount'] as num).toDouble(),
      dueAmount: (map['dueAmount'] as num).toDouble(),
      paymentStatus: map['paymentStatus'] ?? 'Paid',
      createdAt: map['createdAt'],
      updatedAt: map['updatedAt'],
    );
  }
}

class BusinessProfile {
  final String appLogo;
  final String storeName;
  final String billLogo;
  final String billStoreName;
  final String contact;
  final String whatsapp;
  final String address;

  BusinessProfile({
    this.appLogo = '',
    this.storeName = 'Subi Beauty & Store',
    this.billLogo = '',
    this.billStoreName = 'Subi Beauty Parlour',
    this.contact = '9876543210',
    this.whatsapp = '9876543210',
    this.address = 'Near Main Market, Sadat, Ghazipur (U.P.)',
  });

  Map<String, dynamic> toMap() => {
        'id': 1,
        'appLogo': appLogo,
        'storeName': storeName,
        'billLogo': billLogo,
        'billStoreName': billStoreName,
        'contact': contact,
        'whatsapp': whatsapp,
        'address': address,
      };

  factory BusinessProfile.fromMap(Map<String, dynamic> map) => BusinessProfile(
        appLogo: map['appLogo'] ?? '',
        storeName: map['storeName'] ?? 'Subi Beauty & Store',
        billLogo: map['billLogo'] ?? '',
        billStoreName: map['billStoreName'] ?? 'Subi Beauty Parlour',
        contact: map['contact'] ?? '',
        whatsapp: map['whatsapp'] ?? '',
        address: map['address'] ?? '',
      );
}

class OfferModel {
  final int? id;
  final String offerText;
  final String banner;
  final String contact;
  final String whatsapp;
  final int isActive;

  OfferModel({
    this.id,
    required this.offerText,
    this.banner = '',
    this.contact = '',
    this.whatsapp = '',
    this.isActive = 1,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'offerText': offerText,
        'banner': banner,
        'contact': contact,
        'whatsapp': whatsapp,
        'isActive': isActive,
      };

  factory OfferModel.fromMap(Map<String, dynamic> map) => OfferModel(
        id: map['id'],
        offerText: map['offerText'] ?? '',
        banner: map['banner'] ?? '',
        contact: map['contact'] ?? '',
        whatsapp: map['whatsapp'] ?? '',
        isActive: map['isActive'] ?? 1,
      );
}

class ServiceModel {
  final int? id;
  final String serviceName;
  final double? servicePrice;
  final int isActive;

  ServiceModel({
    this.id,
    required this.serviceName,
    this.servicePrice,
    this.isActive = 1,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'serviceName': serviceName,
        'servicePrice': servicePrice,
        'isActive': isActive,
      };

  factory ServiceModel.fromMap(Map<String, dynamic> map) => ServiceModel(
        id: map['id'],
        serviceName: map['serviceName'] ?? '',
        servicePrice: map['servicePrice'] != null ? (map['servicePrice'] as num).toDouble() : null,
        isActive: map['isActive'] ?? 1,
      );
}
