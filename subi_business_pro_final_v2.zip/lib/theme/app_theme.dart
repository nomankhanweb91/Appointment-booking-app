import 'package:flutter/material.dart';

class AppTheme {
  // Ultra Modern Palette: Royal Midnight Navy, Regal Gold & Soft Porcelain
  static const Color primaryNavy = Color(0xFF0A1128);
  static const Color royalIndigo = Color(0xFF1C2541);
  static const Color accentGold = Color(0xFFD4AF37);
  static const Color softGold = Color(0xFFFAF3DD);
  static const Color porcelainBg = Color(0xFFF8FAFC);
  static const Color cardSurface = Colors.white;

  // Status indicators
  static const Color statusGreen = Color(0xFF10B981);
  static const Color statusRed = Color(0xFFEF4444);
  static const Color statusAmber = Color(0xFFF59E0B);

  // Date Priority Colors
  static const Color dateToday = Color(0xFFFFE4E6);      // Rose-Red
  static const Color dateTomorrow = Color(0xFFFEE2E2);   // Red
  static const Color dateDayAfter = Color(0xFFFEF3C7);   // Gold-Amber
  static const Color dateUpcoming = Color(0xFFDCFCE7);   // Emerald
  static const Color datePast = Color(0xFFF1F5F9);       // Soft Muted

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: porcelainBg,
      primaryColor: primaryNavy,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryNavy,
        primary: primaryNavy,
        secondary: accentGold,
        surface: cardSurface,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Colors.white,
        foregroundColor: primaryNavy,
        elevation: 0.5,
        centerTitle: false,
        titleTextStyle: TextStyle(
          color: primaryNavy,
          fontSize: 19,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.2,
        ),
      ),
      cardTheme: CardThemeData(
        color: cardSurface,
        elevation: 1.5,
        shadowColor: Colors.black.withOpacity(0.04),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryNavy,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          textStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        focusedBorder: const OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(14)),
          borderSide: BorderSide(color: primaryNavy, width: 1.5),
        ),
      ),
    );
  }
}
