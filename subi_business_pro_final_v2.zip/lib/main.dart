import 'dart:io';
import 'package:flutter/material.dart';
import 'models/app_models.dart';
import 'screens/appointments/appointment_list_tab.dart';
import 'screens/home/home_screen.dart';
import 'screens/profile/profile_screen.dart';
import 'screens/store_bills/store_bill_list_tab.dart';
import 'services/database/db_helper.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SubiBusinessProApp());
}

class SubiBusinessProApp extends StatelessWidget {
  const SubiBusinessProApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Subi Business Management',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      home: const MainContainer(),
    );
  }
}

class MainContainer extends StatefulWidget {
  const MainContainer({super.key});

  @override
  State<MainContainer> createState() => _MainContainerState();
}

class _MainContainerState extends State<MainContainer> {
  int _currentIndex = 0;
  BusinessProfile _profile = BusinessProfile();

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final p = await DatabaseHelper.instance.getProfile();
    setState(() => _profile = p);
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(onNavigateTab: (idx) => setState(() => _currentIndex = idx)),
      const AppointmentListTab(),
      const StoreBillListTab(),
      ProfileScreen(onProfileUpdated: _loadProfile),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            if (_profile.appLogo.isNotEmpty && File(_profile.appLogo).existsSync())
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.file(File(_profile.appLogo), width: 34, height: 34, fit: BoxFit.cover),
                ),
              ),
            Text(
              _profile.storeName.isNotEmpty ? _profile.storeName : 'Subi Beauty & Store',
              style: const TextStyle(fontWeight: FontWeight.w900, color: AppTheme.primaryNavy),
            ),
          ],
        ),
      ),
      body: screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (idx) => setState(() => _currentIndex = idx),
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppTheme.primaryNavy,
        unselectedItemColor: Colors.grey.shade400,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12),
        unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_outlined), activeIcon: Icon(Icons.dashboard), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.event_available_outlined), activeIcon: Icon(Icons.event_available), label: 'Appointment'),
          BottomNavigationBarItem(icon: Icon(Icons.receipt_long_outlined), activeIcon: Icon(Icons.receipt_long), label: 'Store Bill'),
          BottomNavigationBarItem(icon: Icon(Icons.account_circle_outlined), activeIcon: Icon(Icons.account_circle), label: 'Profile'),
        ],
      ),
    );
  }
}
